package com.miso.thegame.gameMechanics.interfaces;

/**
 * Created by Miso on 19.2.2016.
 */
public interface Movable {
}
