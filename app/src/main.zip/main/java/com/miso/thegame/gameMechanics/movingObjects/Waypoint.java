package com.miso.thegame.gameMechanics.movingObjects;

/**
 * Created by Miso on 26.1.2016.
 */
public class Waypoint {

    public int x;
    public int y;

    public Waypoint(int x, int y){
        this.x = x;
        this.y = y;
    }
}
