package com.miso.thegame.gameMechanics.display.StaticAnimations;

import android.graphics.Bitmap;
import android.graphics.Canvas;

import com.miso.thegame.gameMechanics.nonMovingObjects.StaticObject;

/**
 * Created by Miso on 29.4.2015.
 */
public class StaticAnimation extends StaticObject {

    private Bitmap[] frames;
    private int currentFrame;
    private long startTime;
    private long delay;
    private boolean playedOnce;

    public void setFrames(Bitmap[] frames)
    {
        this.frames = frames;
        currentFrame = 0;
        startTime = System.nanoTime();
    }

    public void setDelay(long d){delay = d;}

    public boolean update()
    {
        long elapsed = (System.nanoTime() - startTime);

        if(elapsed>delay)
        {
            currentFrame++;
            startTime = System.nanoTime();
        }
        if(currentFrame == frames.length){
            currentFrame = 0;
            return true;
        }
        return false;
    }

    public Bitmap getImage()
    {
        return frames[currentFrame];
    }

    public int getFrame(){return currentFrame;}
    public boolean isPlayedOnce(){return playedOnce;}

    public void draw(Canvas canvas){
        try{
            canvas.drawBitmap(this.getImage(),(float) x,(float) y,null);
        }catch(Exception e){
            System.out.println("Aaaa");
        }
    }
}
