package com.miso.thegame.gameMechanics.display;

/**
 * Created by Miso on 17.11.2015.
 */
public class DrawableInterface {
}
