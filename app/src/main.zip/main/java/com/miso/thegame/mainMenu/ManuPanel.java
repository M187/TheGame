package com.miso.thegame.mainMenu;

import android.content.Context;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

/**
 * Created by Miso on 2.1.2016.
 */
public class ManuPanel extends SurfaceView implements SurfaceHolder.Callback {

    public ManuPanel(Context context){
        super(context);
    }





    public void surfaceCreated(SurfaceHolder holder) {
    }

    public void surfaceDestroyed(SurfaceHolder holder) {
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

}
