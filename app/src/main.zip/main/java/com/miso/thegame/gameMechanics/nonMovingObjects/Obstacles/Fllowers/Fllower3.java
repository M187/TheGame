package com.miso.thegame.gameMechanics.nonMovingObjects.Obstacles.Fllowers;

import android.content.res.Resources;
import android.graphics.BitmapFactory;

import com.miso.thegame.R;

/**
 * Created by Miso on 20.11.2015.
 */
public class Fllower3 extends Fllower {

    public Fllower3(Resources res){
        super();
        this.setImage(BitmapFactory.decodeResource(res, R.drawable.fllower3));
    }
}
