package com.miso.thegame.gameMechanics.movingObjects.spells.playerSpells.defensiveSpells;

import com.miso.thegame.gameMechanics.movingObjects.spells.Spell;

/**
 * Created by Miso on 28.11.2015.
 */
public abstract class DeffensiveSpell extends Spell{

    public abstract void update();
}
