package com.miso.thegame.gameMechanics.interfaces;

import android.graphics.Point;

/**
 * Created by Miso on 19.2.2016.
 */
public interface Object {

    public Point getGridCoordinates();

    public Point getPosition();
}
